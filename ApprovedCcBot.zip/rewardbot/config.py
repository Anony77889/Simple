BOT_TOKEN = "8581545651:AAFRY1Znsg34ePWV9x6kIpi1F1zbxocgi1o"
CHANNEL_USERNAME = "@IG_CC_SELLERS"  # example: @MyRewardsChannel
ADMIN_ID = 1295478989  # replace with your telegram numeric id

REWARD_NEW_USER = 2
REWARD_REFERRAL = 3

SEPARATOR = "---"
